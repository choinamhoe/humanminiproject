```bash
Ctrl + Shift + P

Python: Select Interpreter

fastapi_tf 선택

pip install sqlalchemy dotenv pymysql
# app 경로로 이동
python main.py
```
