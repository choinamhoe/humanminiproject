from models.test import get_hello_message

def get_hello_message():
    return "테스트 성공"