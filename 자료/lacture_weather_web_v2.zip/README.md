# 환경 구축

```bash
npx create-react-app weather_web
npm install react-leaflet leaflet
npm install react-chartjs-2 chart.js
npm start

cd src/backend
npm init
npm install express mariadb
npm install cors

node App.js
```
